﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ColorChat.Domain.Models
{
    public class ColorChatColor
    {
        public byte Red { get; set; }
        public byte Green { get; set; }
        public byte Blue { get; set; }
    }
}
